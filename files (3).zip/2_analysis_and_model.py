"""
2_analysis_and_model.py
------------------------
End-to-end data analyst / predictive analytics workflow:

    1. Load & inspect data
    2. Exploratory Data Analysis (EDA) + visualizations
    3. Feature engineering
    4. Train/test split
    5. Train two models: Linear Regression & Random Forest
    6. Evaluate & compare (RMSE, MAE, R^2)
    7. Feature importance
    8. Save charts + a predictions sample to outputs/
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

sns.set_theme(style="whitegrid")

# ----------------------------------------------------------------------
# 1. LOAD DATA
# ----------------------------------------------------------------------
df = pd.read_csv("data/sales_data.csv", parse_dates=["date"])
print("Shape:", df.shape)
print(df.info())
print(df.describe(include="all").T)

# ----------------------------------------------------------------------
# 2. EDA
# ----------------------------------------------------------------------
fig, axes = plt.subplots(2, 2, figsize=(13, 9))

# Sales trend over time
axes[0, 0].plot(df["date"], df["units_sold"], color="#2563eb", linewidth=0.8)
axes[0, 0].set_title("Daily Units Sold Over Time")
axes[0, 0].set_xlabel("Date")
axes[0, 0].set_ylabel("Units Sold")

# Sales by day of week
order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
sns.boxplot(data=df, x="day_of_week", y="units_sold", order=order, ax=axes[0, 1], palette="Blues")
axes[0, 1].set_title("Units Sold by Day of Week")
axes[0, 1].tick_params(axis="x", rotation=30)

# Ad spend vs units sold
axes[1, 0].scatter(df["ad_spend"], df["units_sold"], alpha=0.4, color="#16a34a")
axes[1, 0].set_title("Ad Spend vs Units Sold")
axes[1, 0].set_xlabel("Ad Spend ($)")
axes[1, 0].set_ylabel("Units Sold")

# Correlation heatmap (numeric features)
numeric_cols = ["ad_spend", "price", "competitor_price", "promotion", "holiday", "temperature", "units_sold"]
corr = df[numeric_cols].corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", ax=axes[1, 1])
axes[1, 1].set_title("Correlation Matrix")

plt.tight_layout()
plt.savefig("outputs/eda_overview.png", dpi=150)
plt.close()
print("Saved outputs/eda_overview.png")

# ----------------------------------------------------------------------
# 3. FEATURE ENGINEERING
# ----------------------------------------------------------------------
df["price_gap"] = df["competitor_price"] - df["price"]  # positive = we're cheaper
df["is_weekend"] = df["day_of_week"].isin(["Saturday", "Sunday"]).astype(int)

feature_cols_numeric = ["ad_spend", "price", "competitor_price", "price_gap",
                         "promotion", "holiday", "temperature", "is_weekend", "month"]
feature_cols_categorical = ["day_of_week"]
target_col = "units_sold"

X = df[feature_cols_numeric + feature_cols_categorical]
y = df[target_col]

# ----------------------------------------------------------------------
# 4. TRAIN/TEST SPLIT
# ----------------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print(f"\nTrain size: {len(X_train)}  Test size: {len(X_test)}")

# Preprocessing: one-hot encode day_of_week, pass numeric features through
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(drop="first", handle_unknown="ignore"), feature_cols_categorical),
    ],
    remainder="passthrough",
)

# ----------------------------------------------------------------------
# 5. TRAIN MODELS
# ----------------------------------------------------------------------
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=300, max_depth=8, random_state=42),
}

results = {}
fitted_pipelines = {}

for name, model in models.items():
    pipe = Pipeline(steps=[("prep", preprocessor), ("model", model)])
    pipe.fit(X_train, y_train)
    preds = pipe.predict(X_test)

    rmse = np.sqrt(mean_squared_error(y_test, preds))
    mae = mean_absolute_error(y_test, preds)
    r2 = r2_score(y_test, preds)

    results[name] = {"RMSE": rmse, "MAE": mae, "R2": r2}
    fitted_pipelines[name] = pipe
    print(f"\n{name}")
    print(f"  RMSE: {rmse:.2f}")
    print(f"  MAE:  {mae:.2f}")
    print(f"  R^2:  {r2:.3f}")

results_df = pd.DataFrame(results).T
results_df.to_csv("outputs/model_comparison.csv")
print("\nModel comparison:\n", results_df)

# ----------------------------------------------------------------------
# 6. VISUALIZE: ACTUAL VS PREDICTED (best model = Random Forest)
# ----------------------------------------------------------------------
best_model_name = results_df["R2"].idxmax()
best_pipe = fitted_pipelines[best_model_name]
best_preds = best_pipe.predict(X_test)

fig, axes = plt.subplots(1, 2, figsize=(13, 5))

axes[0].scatter(y_test, best_preds, alpha=0.5, color="#7c3aed")
lims = [min(y_test.min(), best_preds.min()), max(y_test.max(), best_preds.max())]
axes[0].plot(lims, lims, "r--", linewidth=1)
axes[0].set_xlabel("Actual Units Sold")
axes[0].set_ylabel("Predicted Units Sold")
axes[0].set_title(f"Actual vs Predicted ({best_model_name})")

# Model comparison bar chart
results_df[["RMSE", "MAE"]].plot(kind="bar", ax=axes[1], color=["#ef4444", "#f59e0b"])
axes[1].set_title("Model Error Comparison (lower is better)")
axes[1].set_ylabel("Error")
axes[1].tick_params(axis="x", rotation=0)

plt.tight_layout()
plt.savefig("outputs/model_performance.png", dpi=150)
plt.close()
print("Saved outputs/model_performance.png")

# ----------------------------------------------------------------------
# 7. FEATURE IMPORTANCE (Random Forest)
# ----------------------------------------------------------------------
rf_pipe = fitted_pipelines["Random Forest"]
ohe = rf_pipe.named_steps["prep"].named_transformers_["cat"]
cat_feature_names = list(ohe.get_feature_names_out(feature_cols_categorical))
all_feature_names = cat_feature_names + feature_cols_numeric

importances = rf_pipe.named_steps["model"].feature_importances_
imp_df = pd.DataFrame({"feature": all_feature_names, "importance": importances})
imp_df = imp_df.sort_values("importance", ascending=False)

plt.figure(figsize=(9, 6))
sns.barplot(data=imp_df, x="importance", y="feature", palette="viridis")
plt.title("Feature Importance (Random Forest)")
plt.tight_layout()
plt.savefig("outputs/feature_importance.png", dpi=150)
plt.close()
print("Saved outputs/feature_importance.png")
print("\nTop features:\n", imp_df.head(8).to_string(index=False))

# ----------------------------------------------------------------------
# 8. SAVE A SAMPLE OF PREDICTIONS
# ----------------------------------------------------------------------
sample_out = X_test.copy()
sample_out["actual_units_sold"] = y_test.values
sample_out["predicted_units_sold"] = best_preds.round(1)
sample_out.head(20).to_csv("outputs/sample_predictions.csv", index=False)
print("\nSaved outputs/sample_predictions.csv")

print("\n✅ Done. All charts and result files are in the outputs/ folder.")
