# Retail Sales — Predictive Analytics Project

A simple, end-to-end **data analyst + machine learning** project you can run
locally, adapt to real data, and use as a template for other prediction tasks.

## What it does

1. **Generates data** — `1_generate_data.py` creates 2 years of realistic daily
   retail sales data (ad spend, price, promotions, holidays, weather, etc.).
   Swap this step out for your own CSV/database/API to use real data.
2. **Analyzes & predicts** — `2_analysis_and_model.py` runs the full workflow:
   - Exploratory Data Analysis (trends, boxplots, correlations)
   - Feature engineering (price gap vs. competitor, weekend flag, etc.)
   - Train/test split
   - Trains **two models**: Linear Regression and Random Forest
   - Compares them with RMSE, MAE, and R²
   - Plots actual vs. predicted results
   - Ranks which features drive sales the most (feature importance)
   - Saves a sample prediction table

## Project structure

```
sales_predictor/
├── 1_generate_data.py          # creates the dataset
├── 2_analysis_and_model.py     # EDA + ML pipeline
├── data/
│   └── sales_data.csv          # generated dataset
├── outputs/
│   ├── eda_overview.png         # 4-panel exploratory chart
│   ├── model_performance.png    # actual vs predicted + error comparison
│   ├── feature_importance.png   # what drives sales most
│   ├── model_comparison.csv     # RMSE/MAE/R² per model
│   └── sample_predictions.csv   # example predictions vs actuals
└── requirements.txt
```

## How to run it

```bash
pip install -r requirements.txt
python 1_generate_data.py
python 2_analysis_and_model.py
```

All charts and result tables land in `outputs/`.

## Results on the synthetic data

| Model              | RMSE  | MAE   | R²    |
|--------------------|-------|-------|-------|
| Linear Regression  | ~21   | ~16   | ~0.94 |
| Random Forest      | ~29   | ~22   | ~0.89 |

Linear Regression wins here because the synthetic data was generated with a
mostly linear relationship — a good reminder that **more complex models
aren't automatically better**. Always compare against a simple baseline.

The biggest driver of sales in this dataset is **advertising spend**, followed
by **price** and **promotions** — see `outputs/feature_importance.png`.

## How to adapt this to your own data

1. Replace `1_generate_data.py`'s output with your real CSV — just make sure
   you have one row per observation and a numeric target column.
2. In `2_analysis_and_model.py`, update:
   - `feature_cols_numeric` / `feature_cols_categorical` to match your columns
   - `target_col` to your target variable
3. Re-run the script. Everything else (EDA, training, evaluation, charts)
   works automatically.

## Ideas to extend this project

- Add more models (Gradient Boosting, XGBoost) and compare
- Add time-series-aware validation (e.g. `TimeSeriesSplit`) instead of a
  random train/test split, since this is daily data
- Add hyperparameter tuning (`GridSearchCV`)
- Build a small Streamlit/Flask dashboard on top of the trained model
- Add confidence intervals / prediction intervals
