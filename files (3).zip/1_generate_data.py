"""
1_generate_data.py
-------------------
Generates a synthetic (but realistic) retail sales dataset and saves it to
data/sales_data.csv. In a real project you'd replace this step with loading
your own CSV/database/API data.

Features:
    date            - daily date
    day_of_week     - Mon-Sun
    ad_spend        - $ spent on advertising that day
    price           - product price that day
    promotion       - 1 if a promotion ran that day, else 0
    holiday         - 1 if the date is near a holiday, else 0
    competitor_price- competitor's price that day
    temperature     - avg temperature (affects some retail categories)

Target:
    units_sold      - number of units sold that day
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N_DAYS = 730  # 2 years of daily data
start_date = pd.Timestamp("2024-01-01")
dates = pd.date_range(start_date, periods=N_DAYS, freq="D")

df = pd.DataFrame({"date": dates})
df["day_of_week"] = df["date"].dt.day_name()
df["month"] = df["date"].dt.month

# --- Simulate feature values ---
df["ad_spend"] = np.random.gamma(shape=2.0, scale=150, size=N_DAYS).round(2)
df["price"] = np.round(np.random.normal(loc=25, scale=3, size=N_DAYS), 2)
df["competitor_price"] = np.round(df["price"] + np.random.normal(0, 2, N_DAYS), 2)
df["promotion"] = np.random.binomial(1, 0.15, size=N_DAYS)
df["holiday"] = np.random.binomial(1, 0.05, size=N_DAYS)
df["temperature"] = np.round(
    15 + 10 * np.sin(2 * np.pi * (df["date"].dt.dayofyear / 365)) + np.random.normal(0, 3, N_DAYS),
    1,
)

weekend_boost = df["day_of_week"].isin(["Saturday", "Sunday"]).astype(int)

# --- Simulate target: units_sold, driven by a nonlinear combination of features ---
base_demand = 200
ad_effect = 0.35 * df["ad_spend"]
price_effect = -8.0 * (df["price"] - 25)               # higher price -> fewer sales
competitor_effect = 4.0 * (df["competitor_price"] - df["price"])  # relative pricing advantage
promo_effect = 60 * df["promotion"]
holiday_effect = 40 * df["holiday"]
weekend_effect = 35 * weekend_boost
temp_effect = 1.5 * (df["temperature"] - 15)
noise = np.random.normal(0, 20, N_DAYS)

df["units_sold"] = (
    base_demand
    + ad_effect
    + price_effect
    + competitor_effect
    + promo_effect
    + holiday_effect
    + weekend_effect
    + temp_effect
    + noise
).clip(lower=0).round().astype(int)

df.to_csv("data/sales_data.csv", index=False)
print(f"Generated {len(df)} rows -> data/sales_data.csv")
print(df.head())
